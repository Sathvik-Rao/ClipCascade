class Echo:
    def __init__(self, *args, **kwargs):
        print(*args, **kwargs)
